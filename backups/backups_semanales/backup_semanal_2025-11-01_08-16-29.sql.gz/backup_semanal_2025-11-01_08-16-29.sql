-- ========================================================
-- BACKUP SEMANAL - BUFETE POPULAR LA VERAPAZ
-- ========================================================
-- Base de datos: `bufete_popular`
-- Fecha de backup: 2025-11-01 08:16:29
-- Tipo: BACKUP SEMANAL (Retención: 14 días)
-- ========================================================

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


-- --------------------------------------------------------
-- Estructura de tabla para `areas`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `areas`;
CREATE TABLE `areas` (
  `id_area` int(11) NOT NULL AUTO_INCREMENT,
  `area` varchar(60) NOT NULL,
  PRIMARY KEY (`id_area`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Volcado de datos para la tabla `areas` (3 registros)
-- --------------------------------------------------------

INSERT INTO `areas` VALUES ('1', 'Casos de Familia');
INSERT INTO `areas` VALUES ('2', 'Diligencias Voluntarias (vía notarial, sin litis)');
INSERT INTO `areas` VALUES ('3', 'Casos Laborales/Juicios Ordinarios');


-- --------------------------------------------------------
-- Estructura de tabla para `asesores`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `asesores`;
CREATE TABLE `asesores` (
  `id_asesor` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `apellido` varchar(50) NOT NULL,
  `telefono` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id_asesor`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Volcado de datos para la tabla `asesores` (5 registros)
-- --------------------------------------------------------

INSERT INTO `asesores` VALUES ('1', 'Olga Maribel', 'Tello', '58815052');
INSERT INTO `asesores` VALUES ('2', 'Ingrid Jeaneth', 'Lopez Pelaez', '48000030');
INSERT INTO `asesores` VALUES ('4', 'Emilia Patricia', 'Choc Caal', NULL);
INSERT INTO `asesores` VALUES ('11', 'Astrid Johana', 'Lemus Peralta', NULL);
INSERT INTO `asesores` VALUES ('12', 'Gustavo A', 'Diaz Perez', NULL);


-- --------------------------------------------------------
-- Estructura de tabla para `carreras`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `carreras`;
CREATE TABLE `carreras` (
  `id_carrera` int(11) NOT NULL AUTO_INCREMENT,
  `carrera` varchar(80) NOT NULL,
  PRIMARY KEY (`id_carrera`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Volcado de datos para la tabla `carreras` (3 registros)
-- --------------------------------------------------------

INSERT INTO `carreras` VALUES ('1', 'Licenciatura en Ciencias Jurídicas Sociales');
INSERT INTO `carreras` VALUES ('2', 'Licenciatura en Investigación Criminal y Forense');
INSERT INTO `carreras` VALUES ('3', 'Técnico Universitario en Investigación Criminal y Forense');


-- --------------------------------------------------------
-- Estructura de tabla para `estados`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `estados`;
CREATE TABLE `estados` (
  `id_estado` int(11) NOT NULL AUTO_INCREMENT,
  `estado` varchar(25) NOT NULL,
  PRIMARY KEY (`id_estado`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Volcado de datos para la tabla `estados` (2 registros)
-- --------------------------------------------------------

INSERT INTO `estados` VALUES ('1', 'Activo');
INSERT INTO `estados` VALUES ('2', 'Inactivo');


-- --------------------------------------------------------
-- Estructura de tabla para `estados_exp`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `estados_exp`;
CREATE TABLE `estados_exp` (
  `id_estado_exp` int(11) NOT NULL AUTO_INCREMENT,
  `estado_exp` varchar(25) NOT NULL,
  PRIMARY KEY (`id_estado_exp`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Volcado de datos para la tabla `estados_exp` (6 registros)
-- --------------------------------------------------------

INSERT INTO `estados_exp` VALUES ('1', 'Conciliación');
INSERT INTO `estados_exp` VALUES ('2', 'Sentencia de primera');
INSERT INTO `estados_exp` VALUES ('3', 'Sentencia de segunda');
INSERT INTO `estados_exp` VALUES ('4', 'Desestimado');
INSERT INTO `estados_exp` VALUES ('5', 'Descargado');
INSERT INTO `estados_exp` VALUES ('11', 'Fenecido');


-- --------------------------------------------------------
-- Estructura de tabla para `estados_prest`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `estados_prest`;
CREATE TABLE `estados_prest` (
  `id_estado_prest` int(11) NOT NULL AUTO_INCREMENT,
  `estado_prest` varchar(25) NOT NULL,
  PRIMARY KEY (`id_estado_prest`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Volcado de datos para la tabla `estados_prest` (3 registros)
-- --------------------------------------------------------

INSERT INTO `estados_prest` VALUES ('1', 'Vigente');
INSERT INTO `estados_prest` VALUES ('2', 'Vencido');
INSERT INTO `estados_prest` VALUES ('3', 'Devuelto');


-- --------------------------------------------------------
-- Estructura de tabla para `estantes`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `estantes`;
CREATE TABLE `estantes` (
  `id_estante` int(11) NOT NULL AUTO_INCREMENT,
  `estante` int(11) NOT NULL,
  PRIMARY KEY (`id_estante`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Volcado de datos para la tabla `estantes` (5 registros)
-- --------------------------------------------------------

INSERT INTO `estantes` VALUES ('1', '1');
INSERT INTO `estantes` VALUES ('2', '2');
INSERT INTO `estantes` VALUES ('3', '3');
INSERT INTO `estantes` VALUES ('4', '4');
INSERT INTO `estantes` VALUES ('5', '5');


-- --------------------------------------------------------
-- Estructura de tabla para `estudiantes`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `estudiantes`;
CREATE TABLE `estudiantes` (
  `id_estudiante` int(11) NOT NULL AUTO_INCREMENT,
  `dpi_estudiante` varchar(13) DEFAULT NULL,
  `carnetEstudiantil` varchar(7) DEFAULT NULL,
  `nombre` varchar(50) NOT NULL,
  `apellido` varchar(50) NOT NULL,
  `telefono` varchar(15) DEFAULT NULL,
  `id_carrera` int(11) NOT NULL,
  `id_estado` int(11) NOT NULL,
  PRIMARY KEY (`id_estudiante`),
  UNIQUE KEY `carnet_Est` (`carnetEstudiantil`),
  UNIQUE KEY `idx_dpi_unique` (`dpi_estudiante`),
  KEY `id_carrera` (`id_carrera`),
  KEY `id_estado` (`id_estado`),
  CONSTRAINT `estudiantes_ibfk_1` FOREIGN KEY (`id_carrera`) REFERENCES `carreras` (`id_carrera`),
  CONSTRAINT `estudiantes_ibfk_2` FOREIGN KEY (`id_estado`) REFERENCES `estados` (`id_estado`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Volcado de datos para la tabla `estudiantes` (6 registros)
-- --------------------------------------------------------

INSERT INTO `estudiantes` VALUES ('1', '1425361425363', NULL, 'Ruben Darioo', 'Quim Pop', NULL, '1', '2');
INSERT INTO `estudiantes` VALUES ('2', NULL, '2214016', 'Edson Ariel', 'Caal Chiquin', NULL, '1', '1');
INSERT INTO `estudiantes` VALUES ('8', NULL, '2241716', 'Melany Aime', 'Milian Belteton', NULL, '1', '1');
INSERT INTO `estudiantes` VALUES ('9', NULL, '6309799', 'Ingrid Jeaneth', 'Lopez Pelaez', NULL, '1', '2');
INSERT INTO `estudiantes` VALUES ('10', NULL, '20596-1', 'Edson Abraham', 'Xuya Castillo', NULL, '1', '1');
INSERT INTO `estudiantes` VALUES ('11', NULL, NULL, 'Isaias', 'Có', NULL, '1', '1');


-- --------------------------------------------------------
-- Estructura de tabla para `expedientes`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `expedientes`;
CREATE TABLE `expedientes` (
  `id_expediente` int(11) NOT NULL AUTO_INCREMENT,
  `ficha_social` varchar(20) DEFAULT NULL,
  `numero_caso` varchar(2) DEFAULT NULL,
  `anio` year(4) DEFAULT NULL,
  `dpi_interesado_exp` varchar(20) DEFAULT NULL,
  `id_interesado` int(11) NOT NULL,
  `dpi_estudiante_exp` varchar(20) DEFAULT NULL,
  `id_estudiante` int(11) NOT NULL,
  `id_juzgado` int(11) DEFAULT NULL,
  `num_proceso` varchar(50) DEFAULT NULL,
  `folios` int(4) NOT NULL,
  `id_asesor` int(11) DEFAULT NULL,
  `id_tipo_exp` int(11) NOT NULL,
  `id_estado_exp` int(11) NOT NULL,
  `fecha_inicio` date NOT NULL,
  `fecha_audiencia1` date DEFAULT NULL,
  `fecha_audiencia2` date DEFAULT NULL,
  `fecha_finalizacion` date DEFAULT NULL,
  `observaciones` text DEFAULT NULL,
  `id_estante` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_expediente`),
  KEY `id_juzgado` (`id_juzgado`),
  KEY `id_asesor` (`id_asesor`),
  KEY `id_tipo_caso` (`id_tipo_exp`),
  KEY `id_estado_expe` (`id_estado_exp`),
  KEY `id_estante` (`id_estante`),
  KEY `fk_expedientes_interesado` (`id_interesado`),
  KEY `fk_expedientes_estudiante` (`id_estudiante`),
  CONSTRAINT `expedientes_ibfk_3` FOREIGN KEY (`id_juzgado`) REFERENCES `juzgados` (`id_juzgado`),
  CONSTRAINT `expedientes_ibfk_4` FOREIGN KEY (`id_asesor`) REFERENCES `asesores` (`id_asesor`),
  CONSTRAINT `expedientes_ibfk_5` FOREIGN KEY (`id_tipo_exp`) REFERENCES `tipo_caso` (`id_tipo_exp`),
  CONSTRAINT `expedientes_ibfk_6` FOREIGN KEY (`id_estado_exp`) REFERENCES `estados_exp` (`id_estado_exp`),
  CONSTRAINT `expedientes_ibfk_7` FOREIGN KEY (`id_estante`) REFERENCES `estantes` (`id_estante`),
  CONSTRAINT `fk_expedientes_estudiante` FOREIGN KEY (`id_estudiante`) REFERENCES `estudiantes` (`id_estudiante`) ON UPDATE CASCADE,
  CONSTRAINT `fk_expedientes_interesado` FOREIGN KEY (`id_interesado`) REFERENCES `interesados` (`id_interesado`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Volcado de datos para la tabla `expedientes` (5 registros)
-- --------------------------------------------------------

INSERT INTO `expedientes` VALUES ('10', '26-2022', '24', '2022', '2853902281607', '11', NULL, '8', '1', '16019-2018-00496-Srio', '1', '1', '6', '1', '2022-04-22', NULL, NULL, '2023-03-31', '', '2');
INSERT INTO `expedientes` VALUES ('11', '19-22', '16', '2022', '1786315761613', '12', NULL, '10', '1', '16007-2022-00640-Of.4', '30', '2', '6', '11', '2022-03-16', NULL, NULL, '2023-01-20', '', '2');
INSERT INTO `expedientes` VALUES ('14', '2003-0006', '7', '2004', '01676516', '14', NULL, '9', '1', '1357-2003-Of.4', '8', '12', '6', '1', '2004-04-13', NULL, NULL, '2004-04-23', '', '2');
INSERT INTO `expedientes` VALUES ('16', '10-2013', NULL, '2016', '183577891607', '13', NULL, '11', '1', '16007-2016-00404 Of 1', '54', '11', '6', '1', '2016-02-10', NULL, NULL, '2016-12-20', '', '2');
INSERT INTO `expedientes` VALUES ('17', '3', '3', '2025', '01676516', '14', NULL, '10', '2', '3', '8', '1', '2', '1', '2025-10-31', NULL, NULL, NULL, '', '1');


-- --------------------------------------------------------
-- Estructura de tabla para `inicios_fallidos`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `inicios_fallidos`;
CREATE TABLE `inicios_fallidos` (
  `id_log` int(11) NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) DEFAULT NULL,
  `usuario_ingresado` varchar(100) DEFAULT NULL,
  `fecha_hora` datetime NOT NULL,
  `ip` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id_log`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `inicios_fallidos_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Volcado de datos para la tabla `inicios_fallidos` (6 registros)
-- --------------------------------------------------------

INSERT INTO `inicios_fallidos` VALUES ('29', '19', 'dalvarez', '2025-10-22 18:45:30', '::1');
INSERT INTO `inicios_fallidos` VALUES ('32', NULL, 'pruebasss', '2025-10-24 17:56:28', '::1');
INSERT INTO `inicios_fallidos` VALUES ('34', '1', 'Ajlemus', '2025-10-30 01:52:13', '::1');
INSERT INTO `inicios_fallidos` VALUES ('35', NULL, 'Hhh', '2025-10-30 10:47:35', '192.168.1.10');
INSERT INTO `inicios_fallidos` VALUES ('36', NULL, 'Prueba inicio', '2025-10-30 10:48:13', '192.168.1.10');
INSERT INTO `inicios_fallidos` VALUES ('37', NULL, 'admin', '2025-10-31 20:51:12', '::1');


-- --------------------------------------------------------
-- Estructura de tabla para `interesados`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `interesados`;
CREATE TABLE `interesados` (
  `id_interesado` int(11) NOT NULL AUTO_INCREMENT,
  `dpi_interesado` varchar(20) DEFAULT NULL,
  `nombre` varchar(50) NOT NULL,
  `apellido` varchar(50) NOT NULL,
  `telefono` varchar(15) DEFAULT NULL,
  `direccion_exacta` varchar(255) DEFAULT NULL,
  `id_lugar` int(11) NOT NULL,
  PRIMARY KEY (`id_interesado`),
  UNIQUE KEY `idx_dpi_interesado_unique` (`dpi_interesado`),
  KEY `id_lugar` (`id_lugar`),
  CONSTRAINT `interesados_ibfk_1` FOREIGN KEY (`id_lugar`) REFERENCES `lugares` (`id_lugar`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Volcado de datos para la tabla `interesados` (6 registros)
-- --------------------------------------------------------

INSERT INTO `interesados` VALUES ('1', 'O-16 32,177', 'Elena', 'Quej', NULL, 'Aldea Secakpur, Chisec, AV', '4');
INSERT INTO `interesados` VALUES ('2', '1920740241610', 'Albina', 'Guitz Caz', NULL, 'Aldea Sejac 2 horas de Campur, Alta Verapaz Chamil', '2');
INSERT INTO `interesados` VALUES ('11', '2853902281607', 'Glenda Marisol', 'Caal Cac', NULL, 'Barrio San Benito Zona 4 catalina la tnta', '1');
INSERT INTO `interesados` VALUES ('12', '1786315761613', 'Carolina', 'Coc Che', NULL, 'barrio el centro 2, Chisec AV, a dos casas de tienda Don Lino', '7');
INSERT INTO `interesados` VALUES ('13', '183577891607', 'Marta Alicia', 'Juc Cac', '45141073', 'Adyacente Chijacorral', '6');
INSERT INTO `interesados` VALUES ('14', '01676516', 'Ana María', 'Li Xol', NULL, 'San Vicente zona 6', '1');


-- --------------------------------------------------------
-- Estructura de tabla para `juzgados`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `juzgados`;
CREATE TABLE `juzgados` (
  `id_juzgado` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(120) NOT NULL,
  `id_estado` int(11) NOT NULL,
  PRIMARY KEY (`id_juzgado`),
  KEY `id_estado` (`id_estado`),
  CONSTRAINT `juzgados_ibfk_1` FOREIGN KEY (`id_estado`) REFERENCES `estados` (`id_estado`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Volcado de datos para la tabla `juzgados` (6 registros)
-- --------------------------------------------------------

INSERT INTO `juzgados` VALUES ('1', 'Juzgado Pluripersonal de Primera Instancia de Familia del Departamento de Alta Verapaz', '1');
INSERT INTO `juzgados` VALUES ('2', 'Juzgado de Paz Civil, Familia y Trabajo del Municipio de Cobán, departamento de Alta Verapaz', '1');
INSERT INTO `juzgados` VALUES ('3', 'Juzgado de Paz de San Juan Chamelco, Alta Verapaz', '1');
INSERT INTO `juzgados` VALUES ('4', 'Juzgado de Paz de San Pedro Carchá, Alta Verapaz', '1');
INSERT INTO `juzgados` VALUES ('5', 'Juzgado de Paz de Santa Cruz Verapaz, Alta Verapaz', '1');
INSERT INTO `juzgados` VALUES ('6', 'Juzgado de Primera Instancia de Trabajo y Previsión Social y de lo Económico Coactivo del Departamento de Alta Verapaz', '1');


-- --------------------------------------------------------
-- Estructura de tabla para `lugares`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `lugares`;
CREATE TABLE `lugares` (
  `id_lugar` int(11) NOT NULL AUTO_INCREMENT,
  `municipio` varchar(30) NOT NULL,
  PRIMARY KEY (`id_lugar`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Volcado de datos para la tabla `lugares` (7 registros)
-- --------------------------------------------------------

INSERT INTO `lugares` VALUES ('1', 'Cobán');
INSERT INTO `lugares` VALUES ('2', 'San Juan Chamelco');
INSERT INTO `lugares` VALUES ('3', 'Santa Cruz');
INSERT INTO `lugares` VALUES ('4', 'San Pedro Carchá');
INSERT INTO `lugares` VALUES ('5', 'San Cristóbal');
INSERT INTO `lugares` VALUES ('6', 'Tactic');
INSERT INTO `lugares` VALUES ('7', 'Chisec');


-- --------------------------------------------------------
-- Estructura de tabla para `prestamos`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `prestamos`;
CREATE TABLE `prestamos` (
  `id_prestamo` int(11) NOT NULL AUTO_INCREMENT,
  `id_expediente` int(11) NOT NULL,
  `dpi_estudiante_prest` varchar(20) DEFAULT NULL,
  `id_estudiante` int(11) NOT NULL,
  `fecha_entrega` date NOT NULL,
  `fecha_estimada_dev` date DEFAULT NULL,
  `fecha_devolucion` date DEFAULT NULL,
  `id_estado_prest` int(11) NOT NULL,
  PRIMARY KEY (`id_prestamo`),
  KEY `id_expediente` (`id_expediente`),
  KEY `dpi_estudiante` (`dpi_estudiante_prest`),
  KEY `id_estado_prest` (`id_estado_prest`),
  KEY `fk_prestamos_estudiante` (`id_estudiante`),
  CONSTRAINT `fk_prestamos_estudiante` FOREIGN KEY (`id_estudiante`) REFERENCES `estudiantes` (`id_estudiante`) ON UPDATE CASCADE,
  CONSTRAINT `prestamos_ibfk_1` FOREIGN KEY (`id_expediente`) REFERENCES `expedientes` (`id_expediente`),
  CONSTRAINT `prestamos_ibfk_3` FOREIGN KEY (`id_estado_prest`) REFERENCES `estados_prest` (`id_estado_prest`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Volcado de datos para la tabla `prestamos` (4 registros)
-- --------------------------------------------------------

INSERT INTO `prestamos` VALUES ('12', '11', NULL, '1', '2025-10-17', '2025-10-22', '2025-10-24', '3');
INSERT INTO `prestamos` VALUES ('13', '10', NULL, '1', '2025-10-24', '2025-10-31', NULL, '1');
INSERT INTO `prestamos` VALUES ('14', '14', NULL, '2', '2025-10-27', '2025-11-03', NULL, '1');
INSERT INTO `prestamos` VALUES ('15', '17', NULL, '2', '2025-10-31', '2025-11-07', NULL, '1');


-- --------------------------------------------------------
-- Estructura de tabla para `roles`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id_rol` int(11) NOT NULL AUTO_INCREMENT,
  `rol` varchar(20) NOT NULL,
  PRIMARY KEY (`id_rol`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Volcado de datos para la tabla `roles` (2 registros)
-- --------------------------------------------------------

INSERT INTO `roles` VALUES ('1', 'Directora');
INSERT INTO `roles` VALUES ('2', 'Secretaria');


-- --------------------------------------------------------
-- Estructura de tabla para `tipo_caso`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `tipo_caso`;
CREATE TABLE `tipo_caso` (
  `id_tipo_exp` int(11) NOT NULL AUTO_INCREMENT,
  `caso` varchar(50) NOT NULL,
  `id_area` int(11) NOT NULL,
  PRIMARY KEY (`id_tipo_exp`),
  KEY `id_area` (`id_area`),
  CONSTRAINT `tipo_caso_ibfk_1` FOREIGN KEY (`id_area`) REFERENCES `areas` (`id_area`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Volcado de datos para la tabla `tipo_caso` (20 registros)
-- --------------------------------------------------------

INSERT INTO `tipo_caso` VALUES ('1', 'Orales de fijación de pensiones alimenticias', '1');
INSERT INTO `tipo_caso` VALUES ('2', 'Modificación (aumento), reducción de pensión alime', '1');
INSERT INTO `tipo_caso` VALUES ('3', 'Extinción de pensión alimenticia', '1');
INSERT INTO `tipo_caso` VALUES ('4', 'Oral de divorcio', '1');
INSERT INTO `tipo_caso` VALUES ('5', 'Divorcios voluntarios', '1');
INSERT INTO `tipo_caso` VALUES ('6', 'Ejecutivos', '1');
INSERT INTO `tipo_caso` VALUES ('7', 'Paternidad y filiación', '1');
INSERT INTO `tipo_caso` VALUES ('8', 'Guarda y custodia', '1');
INSERT INTO `tipo_caso` VALUES ('9', 'Tutela y protutela', '1');
INSERT INTO `tipo_caso` VALUES ('10', 'Cambios de nombres', '2');
INSERT INTO `tipo_caso` VALUES ('11', 'Asientos extemporáneos de certificados de defunció', '2');
INSERT INTO `tipo_caso` VALUES ('12', 'Certificaciones de partidas de nacimiento y partid', '2');
INSERT INTO `tipo_caso` VALUES ('13', 'Certificaciones de matrimonio civil', '2');
INSERT INTO `tipo_caso` VALUES ('14', 'Certificaciones de unión de hecho', '2');
INSERT INTO `tipo_caso` VALUES ('15', 'Identificación de persona', '2');
INSERT INTO `tipo_caso` VALUES ('16', 'Identificación de terceros', '2');
INSERT INTO `tipo_caso` VALUES ('17', 'Despidos directos justificados', '3');
INSERT INTO `tipo_caso` VALUES ('18', 'Despidos directos injustificados', '3');
INSERT INTO `tipo_caso` VALUES ('19', 'Despidos indirectos', '3');
INSERT INTO `tipo_caso` VALUES ('20', 'Incidentes post-mortem', '3');


-- --------------------------------------------------------
-- Estructura de tabla para `transacciones`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `transacciones`;
CREATE TABLE `transacciones` (
  `id_trans` int(11) NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) NOT NULL,
  `tabla` varchar(50) NOT NULL,
  `id_registro` varchar(50) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `fecha_hora` datetime NOT NULL DEFAULT current_timestamp(),
  `ip` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id_trans`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `transacciones_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=178 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Volcado de datos para la tabla `transacciones` (13 registros)
-- --------------------------------------------------------

INSERT INTO `transacciones` VALUES ('165', '1', 'usuarios', '20', 'Desactivó usuario ID: 20 - Nombre: Mayda Maldonado, Usuario: mmaldonado, Rol: Secretaria, Razón: Usuario de prueba', '2025-10-27 11:43:00', '::1');
INSERT INTO `transacciones` VALUES ('166', '1', 'expedientes', '16', 'Creó expediente ID: 16 - Ficha: 10-2013, Cliente: ID 13 (DPI: 183577891607), Estudiante: ID 11', '2025-10-27 11:49:16', '::1');
INSERT INTO `transacciones` VALUES ('167', '1', 'prestamos', '14', 'Registro de préstamo ID: 14 - Expediente: 14 (2003-0006), Estudiante: Edson Ariel Caal Chiquin (ID: 2, Carnet: 2214016)', '2025-10-27 12:40:34', '::1');
INSERT INTO `transacciones` VALUES ('168', '1', 'estudiantes', '1', 'Se editó al estudiante ID: 1 - Ruben Darioss Quim Pop (DPI: 1425361425363, Carnet: No registrado, Teléfono: No registrado, Carrera: Licenciatura en Ciencias Jurídicas Sociales)', '2025-10-30 02:04:41', '::1');
INSERT INTO `transacciones` VALUES ('169', '1', 'estudiantes', '1', 'Se editó al estudiante ID: 1 - Ruben Dario Quim Pop (DPI: 1425361425363, Carnet: No registrado, Teléfono: No registrado, Carrera: Licenciatura en Ciencias Jurídicas Sociales)', '2025-10-30 02:05:14', '::1');
INSERT INTO `transacciones` VALUES ('170', '1', 'estudiantes', '11', 'Se editó al estudiante ID: 11 - Isaias Cóoo (DPI: No registrado, Carnet: No registrado, Teléfono: No registrado, Carrera: Licenciatura en Ciencias Jurídicas Sociales)', '2025-10-30 02:05:25', '::1');
INSERT INTO `transacciones` VALUES ('171', '1', 'estudiantes', '11', 'Se editó al estudiante ID: 11 - Isaias Có (DPI: No registrado, Carnet: No registrado, Teléfono: No registrado, Carrera: Licenciatura en Ciencias Jurídicas Sociales)', '2025-10-30 02:06:22', '::1');
INSERT INTO `transacciones` VALUES ('172', '1', 'estudiantes', '1', 'Se editó al estudiante ID: 1 - Ruben Darioo Quim Pop (DPI: 1425361425363, Carnet: No registrado, Teléfono: No registrado, Carrera: Licenciatura en Ciencias Jurídicas Sociales)', '2025-10-30 02:06:31', '::1');
INSERT INTO `transacciones` VALUES ('173', '1', 'expedientes', '17', 'Creó expediente ID: 17 - Ficha: 3, Cliente: ID 14 (DPI: 01676516), Estudiante: ID 10', '2025-10-31 15:31:12', '::1');
INSERT INTO `transacciones` VALUES ('174', '1', 'prestamos', '15', 'Registro de préstamo ID: 15 - Expediente: 17 (3), Estudiante: Edson Ariel Caal Chiquin (ID: 2, Carnet: 2214016)', '2025-10-31 15:31:48', '::1');
INSERT INTO `transacciones` VALUES ('175', '1', 'prestamos', '16', 'Registro de préstamo ID: 16 - Expediente: 11 (19-22), Estudiante: Edson Abraham Xuya Castillo (ID: 10, Carnet: 20596-1)', '2025-10-31 15:46:59', '::1');
INSERT INTO `transacciones` VALUES ('176', '1', 'prestamos', '16', 'Devolución del préstamo ID: 16 - Expediente: 11 (19-22), Estudiante: Edson Abraham Xuya Castillo (ID: 10, DPI: )', '2025-10-31 15:47:08', '::1');
INSERT INTO `transacciones` VALUES ('177', '1', 'prestamos', '16', 'Eliminó el préstamo #16 del estudiante Edson Abraham Xuya Castillo (Expediente: 11)', '2025-10-31 15:47:13', '::1');


-- --------------------------------------------------------
-- Estructura de tabla para `usuarios`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE `usuarios` (
  `id_usuario` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `apellido` varchar(50) NOT NULL,
  `usuario` varchar(15) NOT NULL,
  `contrasena` varchar(255) NOT NULL,
  `id_rol` int(11) NOT NULL,
  `id_estado` int(11) NOT NULL,
  PRIMARY KEY (`id_usuario`),
  UNIQUE KEY `usuario` (`usuario`),
  KEY `id_rol` (`id_rol`),
  KEY `id_estado` (`id_estado`),
  CONSTRAINT `usuarios_ibfk_1` FOREIGN KEY (`id_rol`) REFERENCES `roles` (`id_rol`),
  CONSTRAINT `usuarios_ibfk_2` FOREIGN KEY (`id_estado`) REFERENCES `estados` (`id_estado`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Volcado de datos para la tabla `usuarios` (3 registros)
-- --------------------------------------------------------

INSERT INTO `usuarios` VALUES ('1', 'Astrid Johana', 'Lemus Peralta', 'Ajlemus', '$2y$10$bCfKt7hugIv6AqS10ynCbu.rdlushRwnD.h0R/BlHnSO9P9IzfAV2', '1', '1');
INSERT INTO `usuarios` VALUES ('19', 'Delvin Elizabeth', 'Alvarez', 'dalvarez', '$2y$10$2A5Q1VHCkZNnmRXmHfAU.eiLGVD3/kWTQdvFRsXHAoMkxkN54kEJy', '2', '1');
INSERT INTO `usuarios` VALUES ('20', 'Mayda', 'Maldonado', 'mmaldonado', '$2y$10$hHs5OtKmqWNYteqKT1JB4.oEzHYAd8MBuegI0VCNiBSf3EVSy5O/.', '2', '2');


-- ========================================================
-- FIN DEL BACKUP SEMANAL
-- ========================================================
